"use client";

import { useState } from "react";
import { ChevronDown, Check } from "lucide-react";

const TEAMS = [
  "Toulouse FC",
  "Paris Saint-Germain",
  "RC Lens",
  "Olympique de Marseille",
  "AS Monaco",
  "LOSC Lille",
  "Stade Rennais"
];

export function FavoriteTeamCard() {
  const [savedTeam, setSavedTeam] = useState(TEAMS[0]);
  const [selectedTeam, setSelectedTeam] = useState(TEAMS[0]);

  const handleSave = () => {
    setSavedTeam(selectedTeam);
  };

  const isAlreadySaved = selectedTeam === savedTeam;

  return (
    <div className="bg-[#0d1322] p-7 rounded-3xl border border-slate-800/80 shadow-2xl max-w-xl w-full mx-auto">
      
      <div className="mb-6">
        <h3 className="text-2xl font-black tracking-tight text-white mb-1">
          Choisir équipe de cœur
        </h3>
        <p className="text-sm text-slate-400 font-medium">
          Sélectionne ton club favori pour la saison
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-8">
        <div className="relative flex-1">
          <select
            value={selectedTeam}
            onChange={(e) => setSelectedTeam(e.target.value)}
            className="w-full bg-[#0d1322] border border-slate-700/80 text-white font-semibold text-sm rounded-xl px-4 py-3.5 appearance-none focus:outline-none focus:border-slate-500 transition-colors cursor-pointer"
          >
            {TEAMS.map((team) => (
              <option key={team} value={team} className="bg-slate-900 text-white">
                {team}
              </option>
            ))}
          </select>
          <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-white pointer-events-none" />
        </div>

        <button
          onClick={handleSave}
          disabled={isAlreadySaved}
          className={`px-6 py-3.5 rounded-xl font-bold text-sm transition-all duration-200 flex items-center justify-center gap-2 min-w-[180px]
            ${isAlreadySaved 
              ? "bg-[#dcf937] text-black hover:bg-[#c9e625]" 
              : "bg-blue-600 text-white hover:bg-blue-500 cursor-pointer shadow-lg shadow-blue-900/20" 
            }
          `}
        >
          {isAlreadySaved ? (
            <>
              <Check size={18} strokeWidth={3} />
              Club enregistré
            </>
          ) : (
            "Enregistrer"
          )}
        </button>
      </div>

      <div className="mb-8">
        <div className="flex items-center gap-1.5 text-emerald-400 font-semibold text-sm mb-1">
          <Check size={16} strokeWidth={3} />
          <span>Club de cœur enregistré :</span>
        </div>
        <h4 className="text-3xl font-black text-white tracking-tight">
          {savedTeam}
        </h4>
      </div>

      <div className="text-sm font-medium text-slate-400">
        Date butoir : vendredi 21 août 2026
      </div>

    </div>
  );
}

export default FavoriteTeamCard;