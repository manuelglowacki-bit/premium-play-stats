import { useEffect, useState } from "react";
import { CalendarDays, ArrowRight, Flame } from "lucide-react";

const TARGET = new Date("2026-08-21T20:45:00+02:00").getTime();

function read() {
  const remaining = Math.max(0, TARGET - Date.now());
  const pad = (n: number) => String(n).padStart(2, "0");
  return [
    { 
      value: pad(Math.floor(remaining / 86400000)), 
      label: "jours", 
      style: "bg-emerald-950/40 border-emerald-800/40 text-emerald-400" 
    },
    { 
      value: pad(Math.floor(remaining / 3600000) % 24), 
      label: "heures", 
      style: "bg-blue-950/40 border-blue-800/40 text-blue-400" 
    },
    { 
      value: pad(Math.floor(remaining / 60000) % 60), 
      label: "min", 
      style: "bg-amber-950/40 border-amber-800/40 text-amber-400" 
    },
    { 
      value: pad(Math.floor(remaining / 1000) % 60), 
      label: "sec", 
      style: "bg-indigo-950/40 border-indigo-800/40 text-indigo-400" 
    },
  ];
}

const placeholder = [
  { value: "--", label: "jours", style: "bg-emerald-950/40 border-emerald-800/40 text-emerald-400" },
  { value: "--", label: "heures", style: "bg-blue-950/40 border-blue-800/40 text-blue-400" },
  { value: "--", label: "min", style: "bg-amber-950/40 border-amber-800/40 text-amber-400" },
  { value: "--", label: "sec", style: "bg-indigo-950/40 border-indigo-800/40 text-indigo-400" },
];

export function Countdown() {
  const [mounted, setMounted] = useState(false);
  const [units, setUnits] = useState(placeholder);

  useEffect(() => {
    setMounted(true);
    setUnits(read());
    const t = window.setInterval(() => setUnits(read()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const displayUnits = mounted ? units : placeholder;

  return (
    <div className="bg-[#0d1322] text-white p-6 rounded-3xl border border-slate-800/80 shadow-2xl max-w-xl w-full mx-auto">
      {/* En-tête */}
      <div className="flex justify-between items-start mb-7">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-2xl text-slate-400 shrink-0">
            <CalendarDays size={20} />
          </div>
          <div>
            <h3 className="text-2xl font-extrabold tracking-tight text-white">Prochaine journée</h3>
            <p className="text-sm text-slate-400 font-medium">J1 • Vendredi 21 août 2026</p>
          </div>
        </div>
        
        <span className="text-xs font-semibold text-blue-400 bg-blue-950/60 px-3 py-1.5 rounded-full border border-blue-900/50 flex items-center gap-1.5 whitespace-nowrap shadow-md">
          <Flame size={14} className="text-orange-500 fill-orange-500" />
          EN APPROCHE
        </span>
      </div>

      {/* Grille avec couleurs douces et transparentes */}
      <div className="grid grid-cols-4 gap-3 mb-7">
        {displayUnits.map((unit) => (
          <div
            key={unit.label}
            className={`border rounded-2xl py-5 px-2 text-center shadow-inner backdrop-blur-sm ${unit.style}`}
          >
            <b className="block font-black font-mono text-3xl sm:text-4xl leading-none tracking-tighter">
              {unit.value}
            </b>
            <span className="mt-2 block font-medium text-slate-400 text-xs uppercase tracking-wider">
              {unit.label}
            </span>
          </div>
        ))}
      </div>

      {/* Bouton */}
      <button className="w-full bg-slate-900/80 hover:bg-slate-900 border border-slate-800 text-slate-300 py-4 px-6 rounded-2xl flex items-center justify-between transition-all duration-300 group cursor-pointer shadow-xl">
        <span className="text-sm font-semibold tracking-wide text-slate-100">Voir les matchs</span>
        <ArrowRight 
          size={20} 
          className="text-blue-500 group-hover:translate-x-1.5 transition-transform duration-300 ease-in-out"
        />
      </button>
    </div>
  );
}

export default Countdown;