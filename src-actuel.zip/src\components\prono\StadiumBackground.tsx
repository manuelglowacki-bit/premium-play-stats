/**
 * Fond animé "stade + particules", discret et 100% décoratif.
 *
 * Conçu pour rester sous le contenu (z-0) et derrière la photo/voile déjà
 * présents dans AppShell : il se place en DOM *après* la photo pour peindre
 * par-dessus le voile sombre, mais à très faible opacité afin de rester
 * subtil ("discret" demandé dans le brief).
 *
 * - Silhouette de stade abstraite (tribunes + mâts de projecteurs), en SVG,
 *   entièrement vectorielle et générique (aucune reprise d'un stade réel).
 * - Faisceaux de projecteurs qui pivotent lentement (respiration lumineuse).
 * - Particules flottantes (poussière/confettis) en positions déterministes
 *   pour éviter tout écart de rendu serveur/client (SSR-safe, pas de
 *   Math.random() au rendu).
 * - Respecte prefers-reduced-motion.
 *
 * Couleurs alignées sur l'identité actuelle du site (vert émeraude +
 * ambre/or), plutôt que le bleu/or de la maquette d'origine, pour rester
 * cohérent avec le header, la nav et les accents "gold" déjà utilisés
 * ailleurs (Countdown, Leaderboard, Admin...).
 */
import type { CSSProperties } from "react";

const EMERALD = "#10b981";
const AMBER = "#f59e0b";

const PARTICLES = [
  { left: "6%", size: 3, duration: 22, delay: -2, drift: 18, color: EMERALD },
  { left: "13%", size: 2, duration: 26, delay: -14, drift: -22, color: AMBER },
  { left: "21%", size: 4, duration: 19, delay: -6, drift: 12, color: EMERALD },
  { left: "29%", size: 2, duration: 24, delay: -18, drift: -14, color: "#ffffff" },
  { left: "37%", size: 3, duration: 21, delay: -9, drift: 20, color: AMBER },
  { left: "44%", size: 2, duration: 28, delay: -3, drift: -18, color: EMERALD },
  { left: "52%", size: 4, duration: 17, delay: -11, drift: 16, color: AMBER },
  { left: "59%", size: 2, duration: 25, delay: -20, drift: -10, color: "#ffffff" },
  { left: "67%", size: 3, duration: 20, delay: -7, drift: 22, color: EMERALD },
  { left: "74%", size: 2, duration: 23, delay: -16, drift: -16, color: AMBER },
  { left: "82%", size: 4, duration: 27, delay: -4, drift: 14, color: EMERALD },
  { left: "89%", size: 2, duration: 18, delay: -12, drift: -20, color: "#ffffff" },
  { left: "3%", size: 2, duration: 24, delay: -22, drift: 10, color: AMBER },
  { left: "17%", size: 3, duration: 19, delay: -8, drift: -12, color: EMERALD },
  { left: "48%", size: 2, duration: 26, delay: -1, drift: 18, color: "#ffffff" },
  { left: "63%", size: 3, duration: 22, delay: -15, drift: -22, color: AMBER },
  { left: "95%", size: 2, duration: 20, delay: -5, drift: 16, color: EMERALD },
  { left: "40%", size: 4, duration: 29, delay: -19, drift: -8, color: AMBER },
] as const;

export function StadiumBackground() {
  return (
    <div
      aria-hidden
      className="stadium-bg pointer-events-none fixed inset-0 z-0 overflow-hidden"
    >
      {/* Faisceaux de projecteurs : respiration lente, très discrète */}
      <div className="stadium-beam stadium-beam--left" />
      <div className="stadium-beam stadium-beam--right" />

      {/* Silhouette du stade : mâts + tribunes, ancrée en bas de viewport */}
      <svg
        className="stadium-silhouette"
        viewBox="0 0 1440 420"
        preserveAspectRatio="xMidYMax slice"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="standGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={EMERALD} stopOpacity="0" />
            <stop offset="100%" stopColor={EMERALD} stopOpacity="0.5" />
          </linearGradient>
        </defs>

        {/* Tribune arrière incurvée */}
        <path
          d="M0 260 C 220 190, 480 190, 720 220 C 960 250, 1220 190, 1440 250 L1440 420 L0 420 Z"
          fill="url(#standGradient)"
        />
        {/* Toit de la tribune, ligne fine */}
        <path
          d="M0 260 C 220 190, 480 190, 720 220 C 960 250, 1220 190, 1440 250"
          fill="none"
          stroke={AMBER}
          strokeOpacity="0.35"
          strokeWidth="2"
        />
        {/* Trame verticale des gradins */}
        {Array.from({ length: 24 }).map((_, i) => (
          <line
            key={i}
            x1={i * 62}
            y1={230 + Math.sin(i) * 20}
            x2={i * 62}
            y2="420"
            stroke={EMERALD}
            strokeOpacity="0.06"
            strokeWidth="1"
          />
        ))}

        {/* Mâts de projecteurs, gauche et droite */}
        {[96, 1344].map((x, idx) => (
          <g key={x}>
            <rect x={x - 3} y="70" width="6" height="200" fill={EMERALD} opacity="0.18" />
            <rect
              x={x - 46}
              y="34"
              width="92"
              height="40"
              rx="4"
              fill={AMBER}
              opacity="0.16"
            />
            {Array.from({ length: 5 }).map((_, i) => (
              <circle
                key={i}
                cx={x - 34 + i * 17}
                cy="54"
                r="3.4"
                fill={AMBER}
                opacity={idx === 0 ? 0.5 : 0.35}
              />
            ))}
          </g>
        ))}
      </svg>

      {/* Particules flottantes */}
      <div className="stadium-particles absolute inset-0">
        {PARTICLES.map((p, i) => (
          <span
            key={i}
            className="stadium-particle"
            style={
              {
                left: p.left,
                width: p.size,
                height: p.size,
                background: p.color,
                animationDuration: `${p.duration}s`,
                animationDelay: `${p.delay}s`,
                "--drift": `${p.drift}px`,
              } as CSSProperties
            }
          />
        ))}
      </div>
    </div>
  );
}
